﻿Configuration TestAddHostsEntry
{
  Import-DSCResource -module HostsFileRes
  Node AddHostsEntry
  {
    FileResource file
    {
        Path = "C:\test.txt"
        SourcePath = "C:\Windows\System32\drivers\etc\hosts"
        Ensure = "Present"
    } 
  }
  
    Node WebServer
       {
           WindowsFeature IIS
           {
               Ensure               = 'Present'
               Name                 = 'Web-Server'
               IncludeAllSubFeature = $true
  
           }
       }
  
    Node NotWebServer
    {
           WindowsFeature IIS
           {
               Ensure               = 'Absent'
               Name                 = 'Web-Server'
          
           }
    }
}
#TestAddHostsEntry
#Start-DscConfiguration -Wait -Force TestAddHostsEntry